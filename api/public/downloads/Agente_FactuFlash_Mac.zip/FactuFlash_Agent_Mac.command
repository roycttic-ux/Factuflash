#!/bin/bash

# ==============================================================
#             FactuFlash POS Bridge - macOS Launcher
# ==============================================================

# Cambiar al directorio donde se encuentra este script
cd "$(dirname "$0")"

clear
echo -e "\033[1;35m=========================================================\033[0m"
echo -e "\033[1;36m       Iniciando FactuFlash POS Bridge para macOS        \033[0m"
echo -e "\033[1;35m=========================================================\033[0m"
echo ""

# Verificar si python3 está disponible
if ! command -v python3 &> /dev/null
then
    echo -e "\033[1;31m❌ ERROR: Python 3 no está instalado en tu Mac.\033[0m"
    echo "Por favor, descargalo de https://www.python.org/downloads/ e instalalo."
    echo "Asegurate de marcar la casilla 'Add Python to PATH' durante la instalación."
    echo ""
    read -p "Presioná [Enter] para salir..."
    exit 1
fi

# Verificar e instalar dependencias
echo -e "\033[1;33m🔄 Verificando dependencias necesarias...\033[0m"
python3 -m pip install requests pystray pillow --quiet 2>/dev/null

if [ $? -ne 0 ]; then
    echo -e "\033[0;33m⚠️  No se pudieron instalar dependencias automáticamente.\033[0m"
    echo "Intentando instalación con permisos del sistema (sudo)..."
    sudo python3 -m pip install requests pystray pillow
fi

echo -e "\033[1;32m✅ Dependencias listas.\033[0m"
echo -e "\033[1;36m🚀 Ejecutando el agente FactuFlash POS Bridge...\033[0m"
echo "Mantener esta ventana abierta para que el postnet pueda comunicarse."
echo "---------------------------------------------------------"
echo ""

# Ejecutar el agente
python3 factuflash_agent.py

# Si se detiene, pausar
echo ""
echo -e "\033[1;33m⚠️  El agente de FactuFlash se ha detenido.\033[0m"
read -p "Presioná [Enter] para cerrar esta ventana..."
