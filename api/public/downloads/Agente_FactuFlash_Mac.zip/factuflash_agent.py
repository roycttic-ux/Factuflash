#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║           FactuFlash POS Bridge Agent v1.0                   ║
║  Impresora virtual para Postnet — Facturación automática     ║
╚══════════════════════════════════════════════════════════════╝

Modo de uso:
  1. Configurá config.json con tu API URL y token
  2. Ejecutá este programa (o el .exe generado con PyInstaller)
  3. En la configuración de tu postnet, elegí "imprimir en red"
     y apuntá a la IP de esta PC, puerto 9100
  4. ¡Listo! Cada cobro aprobado genera la factura automáticamente

Compilar .exe (requiere Python + PyInstaller):
  pip install pyinstaller pystray pillow requests
  pyinstaller --onefile --noconsole --name factuflash_agent factuflash_agent.py
"""

import socket
import threading
import json
import os
import re
import sys
import time
import logging
from datetime import datetime
from pathlib import Path

try:
    import requests
except ImportError:
    print("ERROR: Falta el paquete 'requests'. Ejecutá: pip install requests")
    sys.exit(1)

# ──────────────────────────────────────────────
#  CONFIGURACIÓN
# ──────────────────────────────────────────────
CONFIG_FILE = Path(__file__).parent / "config.json"

DEFAULT_CONFIG = {
    "api_url":      "https://TU-DOMINIO.com/api/v1",
    "api_token":    "TU_TOKEN_AQUI",
    "notify_afip":  True,
    "listen_port":  9100,
    "log_file":     "factuflash_agent.log"
}

def load_config() -> dict:
    if not CONFIG_FILE.exists():
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(DEFAULT_CONFIG, f, indent=2, ensure_ascii=False)
        print(f"[!] Archivo config.json creado. Editalo con tus datos antes de continuar.")
        sys.exit(0)

    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    if "TU_TOKEN_AQUI" in cfg.get("api_token", ""):
        print("[!] ADVERTENCIA: Configurá tu api_token en config.json")
        sys.exit(1)

    return cfg

# ──────────────────────────────────────────────
#  LOGGER
# ──────────────────────────────────────────────
def setup_logger(log_file: str) -> logging.Logger:
    logger = logging.getLogger("factuflash")
    logger.setLevel(logging.DEBUG)

    fmt = logging.Formatter("[%(asctime)s] %(levelname)s — %(message)s", "%Y-%m-%d %H:%M:%S")

    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setFormatter(fmt)

    ch = logging.StreamHandler()
    ch.setFormatter(fmt)

    logger.addHandler(fh)
    logger.addHandler(ch)
    return logger

# ──────────────────────────────────────────────
#  PARSER DE TICKET ESC/POS
# ──────────────────────────────────────────────
# Patrones que usan los principales procesadores argentinos:
# Fiserv/First Data, Prisma (Visa), Getnet, Naranja X, etc.
APPROVED_KEYWORDS = [
    "aprobado", "approved", "autorizado", "autorizada",
    "aprobada", "transaccion aprobada", "pago aprobado"
]

AMOUNT_PATTERNS = [
    r"(?:total|importe|monto|amount)[:\s\$]*([0-9]+[.,][0-9]{2})",
    r"\$\s*([0-9]+[.,][0-9]{2})",
    r"([0-9]+[.,][0-9]{2})\s*(?:ars|pesos)?",
]

CARD_PATTERN = re.compile(r"\*{4,}[\s\*]*([0-9]{4})")

def clean_escpos(raw_bytes: bytes) -> str:
    """Elimina comandos ESC/POS y retorna texto plano."""
    # Remover secuencias ESC/POS comunes
    cleaned = re.sub(rb'\x1b[^A-Za-z]*[A-Za-z]', b' ', raw_bytes)
    cleaned = re.sub(rb'\x1d[^\x1b]*', b' ', cleaned)
    cleaned = re.sub(rb'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]', b' ', cleaned)
    try:
        return cleaned.decode("latin-1", errors="replace").lower()
    except Exception:
        return raw_bytes.decode("latin-1", errors="replace").lower()

def parse_ticket(raw_bytes: bytes) -> dict | None:
    """
    Parsea un trabajo de impresión del posnet.
    Retorna dict con 'amount' y 'card_last4' si detecta un pago aprobado.
    Retorna None si no es un ticket de pago aprobado.
    """
    text = clean_escpos(raw_bytes)

    # ¿Tiene alguna palabra clave de aprobación?
    is_approved = any(kw in text for kw in APPROVED_KEYWORDS)
    if not is_approved:
        return None

    # Extraer monto
    amount = None
    for pattern in AMOUNT_PATTERNS:
        m = re.search(pattern, text, re.IGNORECASE)
        if m:
            amount_str = m.group(1).replace(",", ".")
            try:
                amount = float(amount_str)
                if amount > 0:
                    break
            except ValueError:
                continue

    if not amount:
        return None

    # Extraer últimos 4 dígitos de tarjeta (opcional)
    card_last4 = None
    m = CARD_PATTERN.search(text)
    if m:
        card_last4 = m.group(1)

    return {
        "amount":     amount,
        "card_last4": card_last4,
        "raw_text":   text[:500]  # Para logging/debug
    }

# ──────────────────────────────────────────────
#  COMUNICACIÓN CON LA API
# ──────────────────────────────────────────────
def notify_api(cfg: dict, payment_data: dict, logger: logging.Logger) -> bool:
    """Envía el pago detectado a la API de FactuFlash."""
    url = cfg["api_url"].rstrip("/") + "/pos/webhook"
    headers = {
        "Authorization": f"Bearer {cfg['api_token']}",
        "Content-Type":  "application/json",
        "Accept":        "application/json",
    }
    payload = {
        "amount":     payment_data["amount"],
        "card_last4": payment_data.get("card_last4"),
        "notify_afip": cfg.get("notify_afip", True),
        "source":     "traditional_pos",
        "detected_at": datetime.now().isoformat(),
    }

    try:
        resp = requests.post(url, json=payload, headers=headers, timeout=15)
        if resp.status_code in (200, 201):
            data = resp.json()
            logger.info(f"✅ Factura creada automáticamente — #{data.get('invoice', {}).get('invoice_number', '?')}")
            return True
        else:
            logger.error(f"❌ API respondió {resp.status_code}: {resp.text[:200]}")
            return False
    except requests.exceptions.ConnectionError:
        logger.error("❌ No se pudo conectar con la API. ¿Hay conexión a internet?")
        return False
    except requests.exceptions.Timeout:
        logger.error("❌ La API tardó demasiado en responder (timeout 15s)")
        return False
    except Exception as e:
        logger.error(f"❌ Error inesperado al llamar a la API: {e}")
        return False

# ──────────────────────────────────────────────
#  SERVIDOR RAW PRINTING (Puerto 9100)
# ──────────────────────────────────────────────
def handle_client(conn: socket.socket, addr: tuple, cfg: dict, logger: logging.Logger):
    """Maneja una conexión entrante del posnet."""
    logger.debug(f"📡 Conexión recibida desde {addr[0]}:{addr[1]}")
    raw_data = b""
    try:
        conn.settimeout(5.0)
        while True:
            chunk = conn.recv(4096)
            if not chunk:
                break
            raw_data += chunk
    except socket.timeout:
        pass  # Normal — el posnet cierra la conexión después de enviar
    finally:
        conn.close()

    if not raw_data:
        logger.debug("  (sin datos recibidos)")
        return

    logger.debug(f"  Recibidos {len(raw_data)} bytes del posnet")

    payment = parse_ticket(raw_data)
    if payment:
        logger.info(f"💳 Pago APROBADO detectado: ${payment['amount']:.2f}" +
                    (f" — Tarjeta *{payment['card_last4']}" if payment.get("card_last4") else ""))
        notify_api(cfg, payment, logger)
    else:
        logger.debug("  No es un ticket de pago aprobado, ignorando.")

def start_server(cfg: dict, logger: logging.Logger):
    """Inicia el servidor TCP en el puerto configurado (default: 9100)."""
    port = cfg.get("listen_port", 9100)

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    try:
        server.bind(("0.0.0.0", port))
        server.listen(5)
        logger.info(f"🖨️  FactuFlash POS Bridge escuchando en puerto {port}")
        logger.info(f"🌐 API destino: {cfg['api_url']}")
        logger.info(f"📝 Notificar ARCA: {'Sí' if cfg.get('notify_afip') else 'No'}")
        logger.info("—" * 50)
        logger.info("En tu postnet, configurá la impresora de red apuntando a:")
        logger.info(f"  IP: (la IP de esta PC en la red local)")
        logger.info(f"  Puerto: {port}")
        logger.info("—" * 50)

        while True:
            try:
                conn, addr = server.accept()
                t = threading.Thread(target=handle_client, args=(conn, addr, cfg, logger), daemon=True)
                t.start()
            except KeyboardInterrupt:
                break
    except OSError as e:
        if e.errno == 10048 or e.errno == 98:  # WSAEADDRINUSE / EADDRINUSE
            logger.error(f"❌ El puerto {port} ya está en uso. ¿Ya está corriendo el agente?")
        else:
            logger.error(f"❌ Error al iniciar servidor: {e}")
    finally:
        server.close()
        logger.info("Servidor detenido.")

# ──────────────────────────────────────────────
#  SYSTEM TRAY (opcional, requiere pystray)
# ──────────────────────────────────────────────
def start_with_tray(cfg: dict, logger: logging.Logger):
    """Inicia el agente con ícono en la bandeja del sistema."""
    try:
        import pystray
        from PIL import Image, ImageDraw

        def create_icon():
            img = Image.new("RGB", (64, 64), color="#6366f1")
            draw = ImageDraw.Draw(img)
            draw.rectangle([16, 20, 48, 44], fill="white")
            draw.rectangle([16, 20, 48, 28], fill="#a5b4fc")
            return img

        def open_logs():
            log_path = cfg.get("log_file", "factuflash_agent.log")
            try:
                if sys.platform == "win32":
                    os.startfile(log_path)
                elif sys.platform == "darwin":
                    import subprocess
                    subprocess.run(["open", log_path])
                else:
                    import subprocess
                    subprocess.run(["xdg-open", log_path])
            except Exception as e:
                logger.error(f"No se pudo abrir el log: {e}")

        def on_quit(icon, item):
            logger.info("Agente detenido desde el tray.")
            icon.stop()
            os._exit(0)

        server_thread = threading.Thread(target=start_server, args=(cfg, logger), daemon=True)
        server_thread.start()

        icon = pystray.Icon(
            "FactuFlash",
            create_icon(),
            "FactuFlash POS Bridge — Activo",
            menu=pystray.Menu(
                pystray.MenuItem("FactuFlash POS Bridge v1.0", lambda: None, enabled=False),
                pystray.MenuItem("Ver logs", lambda: open_logs()),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem("Salir", on_quit),
            )
        )
        icon.run()

    except ImportError:
        logger.info("(pystray no disponible — corriendo sin ícono en bandeja)")
        start_server(cfg, logger)

# ──────────────────────────────────────────────
#  MAIN
# ──────────────────────────────────────────────
if __name__ == "__main__":
    cfg = load_config()
    logger = setup_logger(cfg.get("log_file", "factuflash_agent.log"))

    logger.info("=" * 50)
    logger.info("  FactuFlash POS Bridge Agent v1.0")
    logger.info("=" * 50)

    start_with_tray(cfg, logger)
